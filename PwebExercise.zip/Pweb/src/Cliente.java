/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.net.*;
import java.util.Scanner;
import java.io.*;


public class Cliente {
	public static void main (String args[]) throws Exception {
		String ipeh;
		int porta;
		while (true) {
			System.out.println("Digite aqui o IP do server:");
			BufferedReader meuBuffer = new BufferedReader(new InputStreamReader(System.in));
			ipeh = meuBuffer.readLine();
			System.out.println("\n");
			System.out.println("Digite aqui a porta do server:");
			porta = Integer.parseInt(meuBuffer.readLine());
			Socket socket = new Socket (ipeh,porta);
			Scanner scanner = new Scanner (socket.getInputStream());
			PrintWriter impressora = new PrintWriter (socket.getOutputStream(), true);
			impressora.println("Oi");
			System.out.println(scanner.nextLine());
			scanner.close();
			socket.close();
		}
	}
}