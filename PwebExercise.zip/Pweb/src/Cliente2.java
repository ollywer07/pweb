import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author aluno
 */
public class Cliente2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
       // System.out.println("Digite um texto: ");
       // Scanner ler = new Scanner(System.in);
      //  String texto = ler.nextLine();
        
        Socket soc = new Socket("10.123.15.11", 4040);
 
       // escrita.println(texto);
        
        Scanner lerServidor = new Scanner(soc.getInputStream());
        PrintWriter escrita = new PrintWriter(soc.getOutputStream(),true);
        System.out.println(lerServidor.nextLine());
       lerServidor.close();
       soc.close();
        
        
    }
    
}