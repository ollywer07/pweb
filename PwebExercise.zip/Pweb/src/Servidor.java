/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;
import java.util.Scanner;
import javax.net.ssl.SSLServerSocket;

/**
 *
 * @author aluno
 */
public class Servidor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        ServerSocket srv = new ServerSocket(1234);
        
        System.out.println(" Servidor rodando na porta 1234");
        while (true) {
            Socket soc = srv.accept();
//            Scanner lerCliente = new Scanner(soc.getInputStream());
//            String texto = lerCliente.nextLine();
//            texto = texto.toUpperCase();
            
            String msg;
            msg = Servidor.mensagemDaSorte();
            PrintWriter escrita = new PrintWriter(soc.getOutputStream(), true);
            escrita.println(msg);
        }

    }
    
    
    public static String mensagemDaSorte() {
    	
    	String msg1 = "A vida � bela";
    	
    	String msg2 = "A vida � bela 2 ";
    	
    	String msg3 = "A vida � bela 3 ";
    	
    	String msg4 = "A vida � bela 4 ";
    	
    	String msg5 = "A vida � bela 5 ";
    	
    	String msg6 = "A vida � bela 6 ";
    	
    	String msg7 = "A vida � bela 7 ";
    	
    	String msg8 = "A vida � bela 8 ";
    	
    	String msg9 = "A vida � bela 9 ";
    	
    	String msg10 = "A vida � bela 10 ";
    	
    	int numero;
    	
    	Random gerador = new Random();
    	
    	numero = gerador.nextInt(9);
    	
    	switch (numero) {
    	
    	case 0 : return msg10;
    	
    	case 1 : return msg1;
    
    	case 2 : return msg2;
    	
    	case 3 : return msg3;
    	
    	case 4 : return msg4;
    	
    	case 5 : return msg5;
    	
    	case 6 : return msg6;
    	
    	case 7 : return msg7;
    	
    	case 8 : return msg8;
    	
    	case 9 : return msg9;
    	
    	}
    	
    	
		return null;
    	
    	
    }
}
